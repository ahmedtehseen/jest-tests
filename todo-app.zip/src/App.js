import React, { Component } from "react";
import "./App.css";
import { Routers } from "./pages";

class App extends Component {
  render() {
    return (
      <div className="App">
        <Routers />
      </div>
    );
  }
}

export default App;
